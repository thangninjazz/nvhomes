namespace NVHome.Application.DTOs.Auth;

// DTO trả về sau khi đăng nhập thành công
public class AuthResponse
{
    public Guid UserId { get; set; }
    public string Email { get; set; } = string.Empty;
    public string Token { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
}
